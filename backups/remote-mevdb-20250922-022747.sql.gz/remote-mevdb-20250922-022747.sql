--
-- PostgreSQL database dump
--

\restrict 6RILFPxqnadfCDJCVskCmy4SNeEOXWf4wkWlrY94xKpyOlpadHmvXykkPFvAYD7

-- Dumped from database version 15.14 (Debian 15.14-1.pgdg13+1)
-- Dumped by pg_dump version 15.14 (Debian 15.14-1.pgdg13+1)

-- Started on 2025-09-22 07:27:48 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 217 (class 1259 OID 16403)
-- Name: arbitrage_opportunities; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.arbitrage_opportunities (
    id bigint NOT NULL,
    opportunity_id character varying(50) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    slot bigint NOT NULL,
    venue_sell character varying(50) NOT NULL,
    venue_buy character varying(50) NOT NULL,
    token_pair character varying(100) NOT NULL,
    profit_bps integer NOT NULL,
    amount_in numeric(20,8) NOT NULL,
    expected_amount_out numeric(20,8) NOT NULL,
    price_impact_pct numeric(8,4),
    detection_time_us bigint,
    strategy_type character varying(50),
    raw_opportunity jsonb
);


--
-- TOC entry 216 (class 1259 OID 16402)
-- Name: arbitrage_opportunities_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.arbitrage_opportunities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3470 (class 0 OID 0)
-- Dependencies: 216
-- Name: arbitrage_opportunities_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.arbitrage_opportunities_id_seq OWNED BY public.arbitrage_opportunities.id;


--
-- TOC entry 219 (class 1259 OID 16419)
-- Name: execution_results; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.execution_results (
    id bigint NOT NULL,
    opportunity_id character varying(50) NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    executed boolean NOT NULL,
    success boolean,
    actual_profit_bps integer,
    execution_time_us bigint,
    gas_cost_sol numeric(10,8),
    slippage_bps integer,
    failure_reason text,
    transaction_signature character varying(100),
    bundle_id character varying(100),
    raw_result jsonb
);


--
-- TOC entry 218 (class 1259 OID 16418)
-- Name: execution_results_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.execution_results_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3471 (class 0 OID 0)
-- Dependencies: 218
-- Name: execution_results_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.execution_results_id_seq OWNED BY public.execution_results.id;


--
-- TOC entry 215 (class 1259 OID 16390)
-- Name: orderbook_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orderbook_snapshots (
    id bigint NOT NULL,
    "timestamp" timestamp with time zone DEFAULT now() NOT NULL,
    slot bigint NOT NULL,
    venue character varying(50) NOT NULL,
    market character varying(100) NOT NULL,
    best_bid numeric(20,8),
    best_ask numeric(20,8),
    mid_price numeric(20,8),
    spread_bps integer,
    bid_depth_usd numeric(15,2),
    ask_depth_usd numeric(15,2),
    total_bids integer,
    total_asks integer,
    raw_orderbook jsonb
);


--
-- TOC entry 214 (class 1259 OID 16389)
-- Name: orderbook_snapshots_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.orderbook_snapshots_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3472 (class 0 OID 0)
-- Dependencies: 214
-- Name: orderbook_snapshots_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.orderbook_snapshots_id_seq OWNED BY public.orderbook_snapshots.id;


--
-- TOC entry 221 (class 1259 OID 16432)
-- Name: venue_performance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.venue_performance (
    id bigint NOT NULL,
    venue_pair character varying(100) NOT NULL,
    date date DEFAULT CURRENT_DATE NOT NULL,
    total_opportunities integer DEFAULT 0,
    executed_opportunities integer DEFAULT 0,
    successful_executions integer DEFAULT 0,
    total_profit_bps bigint DEFAULT 0,
    average_profit_bps numeric(8,2),
    average_execution_time_us numeric(10,2),
    success_rate_pct numeric(5,2),
    last_updated timestamp with time zone DEFAULT now()
);


--
-- TOC entry 220 (class 1259 OID 16431)
-- Name: venue_performance_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.venue_performance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3473 (class 0 OID 0)
-- Dependencies: 220
-- Name: venue_performance_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.venue_performance_id_seq OWNED BY public.venue_performance.id;


--
-- TOC entry 3280 (class 2604 OID 16406)
-- Name: arbitrage_opportunities id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.arbitrage_opportunities ALTER COLUMN id SET DEFAULT nextval('public.arbitrage_opportunities_id_seq'::regclass);


--
-- TOC entry 3282 (class 2604 OID 16422)
-- Name: execution_results id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_results ALTER COLUMN id SET DEFAULT nextval('public.execution_results_id_seq'::regclass);


--
-- TOC entry 3278 (class 2604 OID 16393)
-- Name: orderbook_snapshots id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orderbook_snapshots ALTER COLUMN id SET DEFAULT nextval('public.orderbook_snapshots_id_seq'::regclass);


--
-- TOC entry 3284 (class 2604 OID 16435)
-- Name: venue_performance id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.venue_performance ALTER COLUMN id SET DEFAULT nextval('public.venue_performance_id_seq'::regclass);


--
-- TOC entry 3460 (class 0 OID 16403)
-- Dependencies: 217
-- Data for Name: arbitrage_opportunities; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.arbitrage_opportunities (id, opportunity_id, "timestamp", slot, venue_sell, venue_buy, token_pair, profit_bps, amount_in, expected_amount_out, price_impact_pct, detection_time_us, strategy_type, raw_opportunity) FROM stdin;
1	orca_meteora_1	2025-09-06 21:38:59.196208+00	365109930	orca	meteora-dlmm	SOL/USDC	12	1000000000.00000000	1001200000.00000000	\N	35	impact-arb	{}
2	phoenix_raydium_1	2025-09-06 21:40:59.196208+00	365109931	phoenix-clob	raydium	SOL/USDT	8	500000000.00000000	500400000.00000000	\N	29	spread-arbitrage	{}
3	meteora_orca_1	2025-09-06 21:42:59.196208+00	365109932	meteora-dlmm	orca	USDC/USDT	15	2000000000.00000000	2003000000.00000000	\N	42	bin-arbitrage	{}
4	test_opportunity_1757209449	2025-09-07 01:44:10.935239+00	262500000	orca	raydium	SOL/USDC	42	100.50000000	104.20000000	\N	350	test-strategy	\N
5	59jWakaG	2025-09-07 03:08:07.258794+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	81	discard-pile	\N
6	2uPUynAF	2025-09-07 03:08:07.265243+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
7	GXcNajkm	2025-09-07 03:08:07.266062+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
8	2pSHdFnv	2025-09-07 03:08:07.266613+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
9	3mwJ4cVH	2025-09-07 03:08:07.267224+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
10	3nGhw2kr	2025-09-07 03:08:07.267834+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
11	2eggsNFj	2025-09-07 03:08:07.268523+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
12	3uhPtNPr	2025-09-07 03:08:07.269172+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
13	5YfCCgf5	2025-09-07 03:08:07.269627+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
14	3uHYphfP	2025-09-07 03:08:08.259876+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	46	discard-pile	\N
15	7iXhyvkt	2025-09-07 03:08:08.260678+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
16	58UVgZr8	2025-09-07 03:08:08.261309+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
17	2nLj4kcr	2025-09-07 03:08:08.261791+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
18	3vuURUWU	2025-09-07 03:08:08.262527+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
19	3z8TdZE2	2025-09-07 03:08:08.263123+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
20	22rK4JBm	2025-09-07 03:08:08.263547+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
21	234oanzt	2025-09-07 03:08:08.263948+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
22	2EU72jWS	2025-09-07 03:08:08.264507+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
23	2a1RapqE	2025-09-07 03:08:08.265014+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
24	3jQp4zSu	2025-09-07 03:08:08.265717+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
25	4E7TmNcv	2025-09-07 03:08:08.266224+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
26	4LArp4Ha	2025-09-07 03:08:08.266874+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
27	3gLfecHG	2025-09-07 03:08:08.26732+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
28	bX3m9ash	2025-09-07 03:08:08.267777+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
29	3RGGnUF9	2025-09-07 03:08:08.268283+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
30	5V5D1wDq	2025-09-07 03:08:09.25884+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
31	2VSrE191	2025-09-07 03:08:09.259507+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
32	3Yu3JyXt	2025-09-07 03:08:09.260131+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
33	3Va61jkZ	2025-09-07 03:08:09.2606+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
34	59QUfNry	2025-09-07 03:08:09.261146+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
36	2Qf2hMXY	2025-09-07 03:08:09.262069+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	32	discard-pile	\N
37	3vp4ELfS	2025-09-07 03:08:09.262478+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
38	5my9upzZ	2025-09-07 03:08:09.262866+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
39	2j3vBaoJ	2025-09-07 03:08:10.258929+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
40	4TT4cAwd	2025-09-07 03:08:10.259555+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
41	2Q7eDLnf	2025-09-07 03:08:10.260008+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
42	4S3tn5j6	2025-09-07 03:08:10.260391+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
43	VxJ9WZX8	2025-09-07 03:08:10.260818+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
44	5aYwhHd7	2025-09-07 03:08:10.261153+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	47	discard-pile	\N
45	44XLiPez	2025-09-07 03:08:10.261649+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
46	2rNn4tUo	2025-09-07 03:08:10.262047+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	25	discard-pile	\N
47	2svYDSLB	2025-09-07 03:08:10.262675+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	27	discard-pile	\N
49	2ZxoN2Bg	2025-09-07 03:08:10.26358+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
51	4ffHeKku	2025-09-07 03:08:11.259765+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	24	discard-pile	\N
53	4AoPXnWW	2025-09-07 03:08:11.260809+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	32	discard-pile	\N
55	4A43geer	2025-09-07 03:08:11.261526+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	47	discard-pile	\N
57	2zS8mvRA	2025-09-07 03:08:11.262337+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
59	QDExo4Ye	2025-09-07 03:08:11.26332+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
61	3Gk2YmSC	2025-09-07 03:08:11.264579+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
63	2JFzG4Fn	2025-09-07 03:08:11.265459+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
65	2JyHRaMr	2025-09-07 03:08:11.266093+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	26	discard-pile	\N
67	3pftfesN	2025-09-07 03:08:11.266721+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
69	3duhf9RP	2025-09-07 03:08:12.26278+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
71	2zbR1BLB	2025-09-07 03:08:12.263805+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	38	discard-pile	\N
73	5jsitRfy	2025-09-07 03:08:12.264683+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
75	4gKnSm7k	2025-09-07 03:08:12.265592+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	33	discard-pile	\N
77	5AZpUVD2	2025-09-07 03:08:12.266453+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
79	432gp8Fd	2025-09-07 03:08:12.267491+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
81	388eRiKu	2025-09-07 03:08:12.268381+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
83	4yNBW3Dq	2025-09-07 03:08:12.269305+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
85	3DqFbDxM	2025-09-07 03:08:12.270118+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	37	discard-pile	\N
87	5tDFrK3V	2025-09-07 03:08:13.263485+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
89	3WguGFrY	2025-09-07 03:08:13.264595+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	31	discard-pile	\N
91	3CSfkiTZ	2025-09-07 03:08:13.265873+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
93	2AZq9jXM	2025-09-07 03:08:13.2668+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
95	2SyfpHZs	2025-09-07 03:08:13.267823+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
97	5qq3dVVD	2025-09-07 03:08:13.269171+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
99	5wxkJXcm	2025-09-07 03:08:13.270183+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
101	sMbs91VQ	2025-09-07 03:08:13.271314+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
103	JGN7wVTT	2025-09-07 03:08:13.272486+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	53	discard-pile	\N
105	E1UtsFA9	2025-09-07 03:08:13.273566+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
107	3YHNbBr1	2025-09-07 03:08:13.274655+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
109	KafbuQ21	2025-09-07 03:08:14.260965+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
111	3e1rSDMo	2025-09-07 03:08:14.261763+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
113	2tkmDoBS	2025-09-07 03:08:14.262943+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
115	4DPuLhhQ	2025-09-07 03:08:14.263834+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
117	2rpR2vRT	2025-09-07 03:08:14.264723+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
119	3m4rVjjJ	2025-09-07 03:08:14.265582+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
121	KX3hNFR9	2025-09-07 03:08:14.266428+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
123	49PCPZHU	2025-09-07 03:08:14.267414+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
125	3ERQw59L	2025-09-07 03:08:14.268439+00	365151886	raydium-amm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	41	discard-pile	\N
127	3yxgj2zq	2025-09-07 03:08:14.269262+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
129	tWS3a7wC	2025-09-07 03:08:14.270119+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
131	5BW4s7L9	2025-09-07 03:08:14.271118+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	33	discard-pile	\N
133	3fuPFNbr	2025-09-07 03:08:14.272409+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
135	5xBsserG	2025-09-07 03:08:14.273665+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
137	4fZ2ArQL	2025-09-07 03:08:14.274846+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
139	47PWb2K1	2025-09-07 03:08:14.276076+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
141	2yxtCVSs	2025-09-07 03:08:15.260053+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
143	3Gq2HkHy	2025-09-07 03:08:15.260923+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	50	discard-pile	\N
50	3nmTbCmU	2025-09-07 03:08:11.258906+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
52	36Gv6g5w	2025-09-07 03:08:11.26036+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
54	46WnDxEH	2025-09-07 03:08:11.261177+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	24	discard-pile	\N
56	3SHJZhuE	2025-09-07 03:08:11.261847+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	47	discard-pile	\N
58	3uYvH78t	2025-09-07 03:08:11.262879+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
60	F537qths	2025-09-07 03:08:11.264044+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	44	discard-pile	\N
62	3JEKbnB9	2025-09-07 03:08:11.265111+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
64	3GMziYxu	2025-09-07 03:08:11.265734+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
66	2NLrtMB7	2025-09-07 03:08:11.266384+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
68	45c1CzAn	2025-09-07 03:08:12.26188+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	24	discard-pile	\N
70	2kEKE9Nf	2025-09-07 03:08:12.263295+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
72	1v5b1yUF	2025-09-07 03:08:12.264272+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
74	4ZwDXVCU	2025-09-07 03:08:12.265151+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
76	3YWDWCio	2025-09-07 03:08:12.266028+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
78	2d9kNoat	2025-09-07 03:08:12.266868+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
80	3z62NT3Y	2025-09-07 03:08:12.267874+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	46	discard-pile	\N
82	2bzcKz2x	2025-09-07 03:08:12.268856+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	52	discard-pile	\N
84	2Ew4tDCi	2025-09-07 03:08:12.269673+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	23	discard-pile	\N
86	4E69Wxf6	2025-09-07 03:08:13.26269+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	31	discard-pile	\N
88	3Ev9SGzb	2025-09-07 03:08:13.264045+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
90	2nkyi3it	2025-09-07 03:08:13.265288+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
92	5zLnRLGe	2025-09-07 03:08:13.266359+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	32	discard-pile	\N
94	59n2zG7R	2025-09-07 03:08:13.267248+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
96	DSFc1sAj	2025-09-07 03:08:13.268541+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
98	3uxJyLVr	2025-09-07 03:08:13.269808+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
100	2rUViZPe	2025-09-07 03:08:13.270723+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
102	5a19nUf7	2025-09-07 03:08:13.271921+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
104	59Gdr7Z9	2025-09-07 03:08:13.27306+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
106	kNqkvh2a	2025-09-07 03:08:13.27399+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
108	3TKEwmu4	2025-09-07 03:08:14.26042+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
110	238P672A	2025-09-07 03:08:14.26133+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
112	3DbAGaSe	2025-09-07 03:08:14.262292+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
114	2aqBtxhm	2025-09-07 03:08:14.26331+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
116	31zQHBrJ	2025-09-07 03:08:14.264234+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	32	discard-pile	\N
118	3imDD5vK	2025-09-07 03:08:14.265121+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
120	2J7msXG1	2025-09-07 03:08:14.265988+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
122	5Fqyv9nF	2025-09-07 03:08:14.266868+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
124	48ZvPtd4	2025-09-07 03:08:14.267977+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
128	4ntDga7J	2025-09-07 03:08:14.269685+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
130	2zVBNKev	2025-09-07 03:08:14.270623+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	30	discard-pile	\N
132	4Sd6yMui	2025-09-07 03:08:14.271771+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
134	8eyrYu5e	2025-09-07 03:08:14.273056+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
136	MLY57kiG	2025-09-07 03:08:14.274218+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
138	5nNgriry	2025-09-07 03:08:14.275507+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	48	discard-pile	\N
140	3uz5omYE	2025-09-07 03:08:15.259313+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
142	2hXwMnYd	2025-09-07 03:08:15.260483+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	26	discard-pile	\N
144	64WoGAYR	2025-09-07 03:08:15.261294+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
145	2Jtg1R3j	2025-09-07 03:08:15.261663+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
147	3Rd9muLR	2025-09-07 03:08:15.262548+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	25	discard-pile	\N
149	4CKcTpAT	2025-09-07 03:08:15.263298+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
151	yYXAn965	2025-09-07 03:08:15.264183+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
153	2doS3Li8	2025-09-07 03:08:15.265169+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	26	discard-pile	\N
155	2VMNFYrs	2025-09-07 03:08:15.266118+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
157	2cK2H98g	2025-09-07 03:08:15.267154+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
159	21VREoDk	2025-09-07 03:08:16.260093+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	42	discard-pile	\N
161	65qK7wAJ	2025-09-07 03:08:16.261137+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
163	XiWe5PXu	2025-09-07 03:08:16.261927+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	28	discard-pile	\N
165	geo4ve6r	2025-09-07 03:08:16.265061+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
167	46FhnePv	2025-09-07 03:08:16.265974+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
169	3fjefLxu	2025-09-07 03:08:16.266869+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
171	3m7ZnA27	2025-09-07 03:08:16.267938+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
173	3fmfXBCE	2025-09-07 03:08:16.268903+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
175	YqaJo5wb	2025-09-07 03:08:16.269865+00	365151886	whirlpool	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	33	discard-pile	\N
177	5GTgY7En	2025-09-07 03:08:16.270717+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
179	dCsb6qTn	2025-09-07 03:08:16.271555+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	27	discard-pile	\N
181	hgnV25Ga	2025-09-07 03:08:16.272486+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	37	discard-pile	\N
183	5BxpYoT8	2025-09-07 03:08:17.260008+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
185	3FFAxwS3	2025-09-07 03:08:17.261062+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
187	4osSbc4w	2025-09-07 03:08:17.261919+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
189	3DvH5NoC	2025-09-07 03:08:17.2629+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
191	ewZkp3WA	2025-09-07 03:08:17.263677+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
193	3vXJM2fh	2025-09-07 03:08:17.264619+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
195	2aiRPzYA	2025-09-07 03:08:17.265554+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
197	5DFTCF25	2025-09-07 03:08:17.266471+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
199	2i6BazUH	2025-09-07 03:08:17.267285+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
201	2tKGnrxo	2025-09-07 03:08:18.258884+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
203	Mwiw8Mfy	2025-09-07 03:08:18.260161+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	32	discard-pile	\N
205	2cs83ZLm	2025-09-07 03:08:18.261142+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	42	discard-pile	\N
207	qrUpm3fg	2025-09-07 03:08:18.26201+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
209	4p6z1ZTx	2025-09-07 03:08:18.263236+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
211	2oMKVB8W	2025-09-07 03:08:18.264291+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	47	discard-pile	\N
213	5q2ABcmj	2025-09-07 03:08:18.265477+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
215	5mPwaWUp	2025-09-07 03:08:18.266516+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	45	discard-pile	\N
217	5b6csoqw	2025-09-07 03:08:18.267722+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
219	3gaiAzgW	2025-09-07 03:08:18.268876+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
221	3kxMBB2r	2025-09-07 03:08:19.26025+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
223	4zUqVYyM	2025-09-07 03:08:19.261095+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	41	discard-pile	\N
225	5AfFWktm	2025-09-07 03:08:19.26195+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	37	discard-pile	\N
227	2FWGwYae	2025-09-07 03:08:19.262894+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
229	33oL9kqi	2025-09-07 03:08:19.263641+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
231	5NTytffL	2025-09-07 03:08:19.264578+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	46	discard-pile	\N
233	5YyivZkA	2025-09-07 03:08:19.265501+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	43	discard-pile	\N
235	3e92dxbb	2025-09-07 03:08:19.2664+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
237	2S772vH8	2025-09-07 03:08:19.267524+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
239	5T6UZszM	2025-09-07 03:08:20.260901+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	74	discard-pile	\N
146	5A48gfvX	2025-09-07 03:08:15.262099+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
148	46jm92n4	2025-09-07 03:08:15.262872+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
150	62LqbRuU	2025-09-07 03:08:15.263697+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
152	2tMeC2wJ	2025-09-07 03:08:15.264694+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
154	2XU2emRT	2025-09-07 03:08:15.265585+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	23	discard-pile	\N
156	YY93vZjE	2025-09-07 03:08:15.26662+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
158	4tDornfK	2025-09-07 03:08:16.259409+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	47	discard-pile	\N
160	39JmvuJW	2025-09-07 03:08:16.260689+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	42	discard-pile	\N
162	2fYVEHQC	2025-09-07 03:08:16.261594+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
164	2uwE3z8G	2025-09-07 03:08:16.264219+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
166	3JLVDo5x	2025-09-07 03:08:16.265623+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
168	3ikJkiwa	2025-09-07 03:08:16.266437+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
170	jDaywyXn	2025-09-07 03:08:16.267365+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	30	discard-pile	\N
172	52ioe1Kz	2025-09-07 03:08:16.268447+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
174	3GATkUwT	2025-09-07 03:08:16.269433+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
176	32gGTd6E	2025-09-07 03:08:16.270354+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
178	3Kg9Y9v8	2025-09-07 03:08:16.271125+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
180	5sSHLJTr	2025-09-07 03:08:16.272009+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	38	discard-pile	\N
182	4G4bQHua	2025-09-07 03:08:17.2593+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
184	2PG3HbzF	2025-09-07 03:08:17.260567+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
186	3gFws1RF	2025-09-07 03:08:17.261481+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
188	3EVs5k6M	2025-09-07 03:08:17.262416+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
190	2utHsABu	2025-09-07 03:08:17.263297+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
192	5kpSFupF	2025-09-07 03:08:17.264017+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
194	3rK2YRmS	2025-09-07 03:08:17.26496+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
196	349f86fM	2025-09-07 03:08:17.265938+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
198	zze2ZXPV	2025-09-07 03:08:17.266881+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
200	3Q4fvHUS	2025-09-07 03:08:17.267651+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	51	discard-pile	\N
202	3idq3Tu9	2025-09-07 03:08:18.259627+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
204	CUgUTdAw	2025-09-07 03:08:18.260738+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
206	4jKQJ2FK	2025-09-07 03:08:18.261606+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
208	3uP5bXxZ	2025-09-07 03:08:18.262469+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
210	4hDVotNs	2025-09-07 03:08:18.263713+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	33	discard-pile	\N
212	5pXHqHBM	2025-09-07 03:08:18.264832+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
214	52nHvjcN	2025-09-07 03:08:18.265889+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
216	2pYDKQwx	2025-09-07 03:08:18.267023+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
218	66y4eKKY	2025-09-07 03:08:18.268293+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
220	25kqLSds	2025-09-07 03:08:19.259579+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
222	2FKAZfMN	2025-09-07 03:08:19.260719+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
224	5hnGEBCo	2025-09-07 03:08:19.261529+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
226	3KQwXVpr	2025-09-07 03:08:19.26242+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	36	discard-pile	\N
228	3F93E5dp	2025-09-07 03:08:19.263278+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
230	4CgWgyAy	2025-09-07 03:08:19.264148+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
232	4R3HNvMm	2025-09-07 03:08:19.265005+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
234	2ioDS9fe	2025-09-07 03:08:19.265893+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
236	4duHjWMf	2025-09-07 03:08:19.266914+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
238	3Ad3XMvy	2025-09-07 03:08:20.260252+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
240	KysPY3G7	2025-09-07 03:08:20.261563+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
241	5FJWy7Y2	2025-09-07 03:08:20.262252+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
243	3V58ZFvX	2025-09-07 03:08:20.263433+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
245	eZ7KJ9Px	2025-09-07 03:08:20.264635+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
247	2i7ThtY2	2025-09-07 03:08:20.265419+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	32	discard-pile	\N
249	3Wk5vKQ9	2025-09-07 03:08:20.266443+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
251	5aK9N4g7	2025-09-07 03:08:20.267486+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
255	HQgvEytd	2025-09-07 03:08:20.269029+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
257	3RUPEhj3	2025-09-07 03:08:20.269974+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
259	5aTxbgxY	2025-09-07 03:08:20.270849+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
261	265rp9cq	2025-09-07 03:08:20.271818+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
263	2i1tjr1j	2025-09-07 03:08:20.27262+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
265	421oumEv	2025-09-07 03:08:21.260413+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	45	discard-pile	\N
267	2GwrKHAQ	2025-09-07 03:08:21.261449+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
269	51RX1G8x	2025-09-07 03:08:21.262429+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
271	3vUSX6ht	2025-09-07 03:08:21.263339+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
273	RVUuY3wU	2025-09-07 03:08:21.264181+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
275	442iJgx8	2025-09-07 03:08:21.265087+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
277	5ayVcTrf	2025-09-07 03:08:21.26588+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	53	discard-pile	\N
279	4QNGbr1e	2025-09-07 03:08:21.266764+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	59	discard-pile	\N
281	58YxYSkE	2025-09-07 03:08:21.267625+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
283	24SMUTAa	2025-09-07 03:08:21.268466+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	22	discard-pile	\N
285	iRmB7QDe	2025-09-07 03:08:21.269324+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
287	T2BL5P1f	2025-09-07 03:08:22.262409+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
289	5jVSdUaA	2025-09-07 03:08:22.26352+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
291	2uEFXKQL	2025-09-07 03:08:22.26443+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	38	discard-pile	\N
293	4DwtJjUt	2025-09-07 03:08:22.265504+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	42	discard-pile	\N
295	tX8tVodi	2025-09-07 03:08:22.266556+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	46	discard-pile	\N
297	3hKTVyDF	2025-09-07 03:08:23.259914+00	365151886	whirlpool	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
299	3subEaFX	2025-09-07 03:08:23.260801+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
301	3Ryz5AMo	2025-09-07 03:08:23.261609+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
303	28c5zSMM	2025-09-07 03:08:23.262574+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
305	3U1RRQNf	2025-09-07 03:08:23.263373+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
307	65EXirPh	2025-09-07 03:08:23.264335+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	37	discard-pile	\N
309	4ohiT1Fo	2025-09-07 03:08:24.259645+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
311	4UiWvTaq	2025-09-07 03:08:24.260873+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	43	discard-pile	\N
313	56bWBU3J	2025-09-07 03:08:24.262062+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	37	discard-pile	\N
315	qbbqbdix	2025-09-07 03:08:24.263113+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
317	5RiHP1mJ	2025-09-07 03:08:24.264262+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
319	27TrUrhp	2025-09-07 03:08:24.265287+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
321	27mf69jg	2025-09-07 03:08:24.266178+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
323	4ofj2Pc1	2025-09-07 03:08:24.266894+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
325	4ZSKng7a	2025-09-07 03:08:24.267719+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
327	5JiJrEMB	2025-09-07 03:08:24.268588+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	28	discard-pile	\N
329	3FNxphwi	2025-09-07 03:08:24.269523+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
331	3gn3e1f6	2025-09-07 03:08:25.260627+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
333	28SUJTwT	2025-09-07 03:08:25.261913+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	41	discard-pile	\N
335	CXjo7yMw	2025-09-07 03:08:25.263216+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
337	3Y4JGJoq	2025-09-07 03:08:25.264347+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
242	5aEzRXxD	2025-09-07 03:08:20.262905+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
244	2AugdZ4C	2025-09-07 03:08:20.264012+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
246	4ohJM66v	2025-09-07 03:08:20.264996+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
248	2qJF74Ur	2025-09-07 03:08:20.265817+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
250	48M9kmkW	2025-09-07 03:08:20.267072+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	43	discard-pile	\N
252	668e8pHP	2025-09-07 03:08:20.267895+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	46	discard-pile	\N
254	3DPnFmPT	2025-09-07 03:08:20.268664+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
256	4rMUAmMi	2025-09-07 03:08:20.269535+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	43	discard-pile	\N
258	2iVrEze2	2025-09-07 03:08:20.270422+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
260	3Ao8az1h	2025-09-07 03:08:20.271289+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
262	2DAzE4m7	2025-09-07 03:08:20.272185+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
264	4FL6SGe4	2025-09-07 03:08:21.25965+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	43	discard-pile	\N
266	Vfx7BWVJ	2025-09-07 03:08:21.260894+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
268	5iFRLBoa	2025-09-07 03:08:21.261873+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	43	discard-pile	\N
270	tFUR2nUN	2025-09-07 03:08:21.262877+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
272	2qbiQsaw	2025-09-07 03:08:21.263789+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
274	3bGCXGKA	2025-09-07 03:08:21.264667+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	25	discard-pile	\N
276	4H4CN7tA	2025-09-07 03:08:21.265488+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
278	mxrB3atB	2025-09-07 03:08:21.266336+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	45	discard-pile	\N
280	3kvtjTiL	2025-09-07 03:08:21.267224+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	36	discard-pile	\N
282	3vDMb7BC	2025-09-07 03:08:21.268088+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
284	5mc5XwPx	2025-09-07 03:08:21.268867+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
286	5FyEcq8S	2025-09-07 03:08:22.261626+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	53	discard-pile	\N
288	5sSceU6T	2025-09-07 03:08:22.263023+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	31	discard-pile	\N
290	3oWVvn3J	2025-09-07 03:08:22.263981+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
292	3nVjTJDg	2025-09-07 03:08:22.264988+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	34	discard-pile	\N
294	2JW2tZ1L	2025-09-07 03:08:22.266025+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	44	discard-pile	\N
296	4cgiGg9x	2025-09-07 03:08:23.259025+00	365151886	whirlpool	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	37	discard-pile	\N
298	2AMxxwRa	2025-09-07 03:08:23.260394+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
300	nnxXLmCJ	2025-09-07 03:08:23.261251+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	32	discard-pile	\N
302	43hcN5RA	2025-09-07 03:08:23.262178+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	33	discard-pile	\N
304	5HuKTF2k	2025-09-07 03:08:23.262968+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
306	4SBTddMT	2025-09-07 03:08:23.263899+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
308	5gDR7KLU	2025-09-07 03:08:23.26483+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
310	5Fx9hFuF	2025-09-07 03:08:24.260281+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	37	discard-pile	\N
312	4pZNVGgC	2025-09-07 03:08:24.261467+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	55	discard-pile	\N
314	3wGuRYWu	2025-09-07 03:08:24.262641+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
316	4b7n25Un	2025-09-07 03:08:24.263717+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	59	discard-pile	\N
318	2dwJnxTH	2025-09-07 03:08:24.264767+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
320	rf8VuXtD	2025-09-07 03:08:24.265732+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
322	2VkjQAZR	2025-09-07 03:08:24.266553+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
324	2JrKnYrX	2025-09-07 03:08:24.267327+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
326	4kGfXjjd	2025-09-07 03:08:24.268193+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
328	3SXRRnnB	2025-09-07 03:08:24.269025+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
330	P8RcWBAX	2025-09-07 03:08:25.259858+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
332	wYEuCghM	2025-09-07 03:08:25.261267+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	27	discard-pile	\N
334	2em9AEEo	2025-09-07 03:08:25.262591+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	39	discard-pile	\N
336	2ksZqRuE	2025-09-07 03:08:25.263769+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
338	3QKuKg1M	2025-09-07 03:08:25.264907+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
340	JBjvNFRj	2025-09-07 03:08:25.26576+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
342	4DCTwnHx	2025-09-07 03:08:25.266788+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	76	discard-pile	\N
344	6PQmFFLN	2025-09-07 03:08:25.267928+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
346	48Z82ywT	2025-09-07 03:08:25.269095+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	51	discard-pile	\N
348	5mKNFkBm	2025-09-07 03:08:25.27015+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
350	5ASqEvJ1	2025-09-07 03:08:25.270816+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
352	RbmCCqHw	2025-09-07 03:08:25.271827+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
354	3CNCoTcy	2025-09-07 03:08:25.272832+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
356	56k3iLrc	2025-09-07 03:08:25.274047+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
358	38ESQgQ2	2025-09-07 03:08:26.260754+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
360	3q1g9NeX	2025-09-07 03:08:26.26169+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	30	discard-pile	\N
362	QsRLfJ4X	2025-09-07 03:08:26.26264+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
364	4Tyu8ASc	2025-09-07 03:08:26.26376+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	42	discard-pile	\N
366	2fUMFeEF	2025-09-07 03:08:26.264814+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
368	2GNg3AR3	2025-09-07 03:08:26.265859+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	45	discard-pile	\N
370	5Lj5Zvxe	2025-09-07 03:08:26.266862+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
372	3UwyGkQc	2025-09-07 03:08:26.267851+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
374	3MJh1D9J	2025-09-07 03:08:26.269013+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	41	discard-pile	\N
376	4zeiLNVN	2025-09-07 03:08:26.269914+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
378	41YqSD9a	2025-09-07 03:08:26.270865+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	53	discard-pile	\N
380	2L4awJ7x	2025-09-07 03:08:27.260321+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	47	discard-pile	\N
382	41nXLjD6	2025-09-07 03:08:27.261272+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
384	3jyxfqap	2025-09-07 03:08:28.260551+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
386	3aXGAMCe	2025-09-07 03:08:28.261645+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	26	discard-pile	\N
388	3it8Sbqj	2025-09-07 03:08:28.262857+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	23	discard-pile	\N
390	48peKaLo	2025-09-07 03:08:28.264318+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	51	discard-pile	\N
392	3hyxTPbr	2025-09-07 03:08:28.265496+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	45	discard-pile	\N
394	3pQ4ckj5	2025-09-07 03:08:28.266597+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	25	discard-pile	\N
396	2ysBddG2	2025-09-07 03:08:29.259738+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
398	3rufPfm1	2025-09-07 03:08:29.260929+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	27	discard-pile	\N
400	4m9Syyjj	2025-09-07 03:08:29.26184+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
402	2nofg7ub	2025-09-07 03:08:29.263267+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
404	2EKrjbu7	2025-09-07 03:08:29.264564+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
406	wmEWJWT1	2025-09-07 03:08:29.265624+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	45	discard-pile	\N
408	3KKdPoSX	2025-09-07 03:08:29.266749+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
410	2YSjJ2g3	2025-09-07 03:08:30.260757+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	54	discard-pile	\N
412	SDRERPif	2025-09-07 03:08:30.262178+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
414	3CgsfyxV	2025-09-07 03:08:30.263405+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
416	3d3Xef3v	2025-09-07 03:08:30.264805+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
418	4JiVoVB7	2025-09-07 03:08:30.265732+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
420	127UWU3o	2025-09-07 03:08:30.266632+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
422	3BK55R7n	2025-09-07 03:08:30.267694+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
424	5FSjqUFp	2025-09-07 03:08:30.268807+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
426	3yf3LYqP	2025-09-07 03:08:30.269902+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	26	discard-pile	\N
428	3xd8Cv6L	2025-09-07 03:08:30.271068+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
430	4MGD5AXU	2025-09-07 03:08:30.27216+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	33	discard-pile	\N
432	3cy2BX3Y	2025-09-07 03:08:30.273393+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
339	3SM34C6o	2025-09-07 03:08:25.265386+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	46	discard-pile	\N
341	2sEeTrPW	2025-09-07 03:08:25.266181+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
343	61asKWwm	2025-09-07 03:08:25.267411+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
345	fVbXsTNf	2025-09-07 03:08:25.26859+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
347	5Lpco78p	2025-09-07 03:08:25.269644+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
349	3sQWh4iS	2025-09-07 03:08:25.270495+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
351	5uEKqyVh	2025-09-07 03:08:25.271216+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
353	3AuMEg2L	2025-09-07 03:08:25.272396+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
355	2YhUYhJb	2025-09-07 03:08:25.27348+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	41	discard-pile	\N
357	2fg9ef44	2025-09-07 03:08:26.259897+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
359	3nr9R77o	2025-09-07 03:08:26.261254+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
361	2MfkCP8E	2025-09-07 03:08:26.262193+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	34	discard-pile	\N
363	3rw4qCu5	2025-09-07 03:08:26.263166+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
365	5yv1a49o	2025-09-07 03:08:26.264199+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
367	2CAK5h9t	2025-09-07 03:08:26.265361+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
369	3cKRTpgj	2025-09-07 03:08:26.266357+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
371	2BTkWs2B	2025-09-07 03:08:26.267279+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
373	5WrM3aJp	2025-09-07 03:08:26.268437+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
375	wsekDSEs	2025-09-07 03:08:26.269505+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
377	59azsm1Q	2025-09-07 03:08:26.270365+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	51	discard-pile	\N
379	2EHxzrJc	2025-09-07 03:08:27.259638+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
381	61X9uUxc	2025-09-07 03:08:27.260879+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	47	discard-pile	\N
383	2wRoGGrj	2025-09-07 03:08:28.259918+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
385	3Ymznw2Y	2025-09-07 03:08:28.261105+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
387	3DZH9rBv	2025-09-07 03:08:28.262148+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
389	67XRsM47	2025-09-07 03:08:28.263591+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	40	discard-pile	\N
391	2qrqGw6W	2025-09-07 03:08:28.264854+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	40	discard-pile	\N
393	2YY7vmsq	2025-09-07 03:08:28.265915+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	34	discard-pile	\N
395	4962wanw	2025-09-07 03:08:29.258895+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
397	3FGjok6D	2025-09-07 03:08:29.260335+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	27	discard-pile	\N
399	2Sq1n4D5	2025-09-07 03:08:29.26145+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	43	discard-pile	\N
401	47ULkKLB	2025-09-07 03:08:29.262635+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
403	3bF1o6Fa	2025-09-07 03:08:29.263883+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
405	5NPHuwzd	2025-09-07 03:08:29.265046+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	47	discard-pile	\N
407	5kzb1Tfo	2025-09-07 03:08:29.266157+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
409	2fvYyaZr	2025-09-07 03:08:29.267356+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
411	6uPoVGdd	2025-09-07 03:08:30.26152+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
413	5qbdgM1C	2025-09-07 03:08:30.262786+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
415	2Lyowmom	2025-09-07 03:08:30.264145+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
417	4rXi8ncL	2025-09-07 03:08:30.265262+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
419	41nJPnep	2025-09-07 03:08:30.266131+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
421	5jfxJK1U	2025-09-07 03:08:30.267198+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
423	2GzJQHa9	2025-09-07 03:08:30.268182+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
425	33aiQyJp	2025-09-07 03:08:30.269345+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
427	232GdnhQ	2025-09-07 03:08:30.270513+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
429	2qxifTv5	2025-09-07 03:08:30.27164+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
431	x9S9rvEy	2025-09-07 03:08:30.272852+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	42	discard-pile	\N
433	3z7kEeA2	2025-09-07 03:08:30.273863+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	46	discard-pile	\N
434	erS52SoQ	2025-09-07 03:08:30.274411+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	43	discard-pile	\N
436	2PVVaJ24	2025-09-07 03:08:30.27565+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
438	3u12W9Pc	2025-09-07 03:08:30.276902+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
440	KH1xRrtF	2025-09-07 03:08:31.261858+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	24	discard-pile	\N
442	UCKC67Sp	2025-09-07 03:08:31.263057+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
444	3Sgr5GEe	2025-09-07 03:08:31.263851+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
446	26baSeBQ	2025-09-07 03:08:31.264788+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
448	3JjdqQ3d	2025-09-07 03:08:31.265729+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
450	5K48LQpu	2025-09-07 03:08:31.266776+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
452	3GnQwhTa	2025-09-07 03:08:31.267885+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
454	49rJXX4Z	2025-09-07 03:08:32.259376+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
456	2dYda2nr	2025-09-07 03:08:32.260449+00	365151886	raydium-clmm	cl-impact-arb	CONCENTRATED-LIQUIDITY	12	0.00000000	0.00000000	\N	25	discard-pile	\N
458	4RSaJNdL	2025-09-07 03:08:32.261343+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	33	discard-pile	\N
460	3B7BsYW1	2025-09-07 03:08:32.262242+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
462	593njRjZ	2025-09-07 03:08:32.263199+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	44	discard-pile	\N
464	38fLNYWo	2025-09-07 03:08:32.264248+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
466	384g39FA	2025-09-07 03:08:32.265203+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	33	discard-pile	\N
468	2gEsdRCQ	2025-09-07 03:08:32.266302+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
470	44fb9wyd	2025-09-07 03:08:32.267642+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
472	2TFhiWRV	2025-09-07 03:08:32.270947+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
474	2gTafiZi	2025-09-07 03:08:32.272488+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	21	discard-pile	\N
476	A38EWvrA	2025-09-07 03:08:33.260438+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	27	discard-pile	\N
478	2NQ4mrvt	2025-09-07 03:08:33.261635+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
480	34vEzRWU	2025-09-07 03:08:33.262611+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	26	discard-pile	\N
482	26jES4WB	2025-09-07 03:08:33.263421+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
484	YrYYYgUj	2025-09-07 03:08:33.264467+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
486	2oXLjsPc	2025-09-07 03:08:33.265546+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
488	46g2fuZJ	2025-09-07 03:08:33.266695+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
490	4zKXMjqi	2025-09-07 03:08:33.267832+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
492	3XaxxYrY	2025-09-07 03:08:34.259499+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
494	4mBU11Sq	2025-09-07 03:08:34.260478+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
496	2Ttro75C	2025-09-07 03:08:34.261467+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	41	discard-pile	\N
498	2mGXWCan	2025-09-07 03:08:34.262374+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	40	discard-pile	\N
500	63M5vFXs	2025-09-07 03:08:34.263179+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
502	2VLQtyom	2025-09-07 03:08:34.26408+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	33	discard-pile	\N
504	zkPvbE4h	2025-09-07 03:08:34.264958+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	47	discard-pile	\N
506	3fmDzk6i	2025-09-07 03:08:34.265727+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
508	2kn4aoCs	2025-09-07 03:08:34.266639+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
510	4C1r4eG9	2025-09-07 03:08:34.267562+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
512	56NV786j	2025-09-07 03:08:35.260374+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
514	23LMKpUy	2025-09-07 03:08:35.261471+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	25	discard-pile	\N
516	3Aid3C8u	2025-09-07 03:08:35.262227+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	44	discard-pile	\N
518	4x6yFmzs	2025-09-07 03:08:35.263446+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	38	discard-pile	\N
520	dFqonWnJ	2025-09-07 03:08:35.26443+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	45	discard-pile	\N
522	3LrMjnMV	2025-09-07 03:08:35.265331+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
524	39UXTyw2	2025-09-07 03:08:35.266546+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
526	44YpWMX3	2025-09-07 03:08:35.267481+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
528	2JfY4C3q	2025-09-07 03:08:35.268385+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
435	5UwodJgd	2025-09-07 03:08:30.274901+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	39	discard-pile	\N
437	2r2BM8Yv	2025-09-07 03:08:30.276311+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
439	2NAms9jZ	2025-09-07 03:08:30.277488+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	42	discard-pile	\N
441	2s5YqYzm	2025-09-07 03:08:31.26251+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
443	5cLP6e5f	2025-09-07 03:08:31.263487+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
445	3Qf6Lkd6	2025-09-07 03:08:31.264314+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	34	discard-pile	\N
447	4MtWTxjX	2025-09-07 03:08:31.265231+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
449	3isRjLNp	2025-09-07 03:08:31.266317+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	40	discard-pile	\N
451	3SkkoTqf	2025-09-07 03:08:31.267387+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
453	3sWzA1cU	2025-09-07 03:08:31.268439+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
455	3DpTJnje	2025-09-07 03:08:32.260001+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	33	discard-pile	\N
457	3oiLrVBH	2025-09-07 03:08:32.2609+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
459	2dJUcg4U	2025-09-07 03:08:32.261753+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
461	2bou3jZf	2025-09-07 03:08:32.262806+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	37	discard-pile	\N
463	59bfHgLh	2025-09-07 03:08:32.26372+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
465	ByJFGPoq	2025-09-07 03:08:32.264745+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
467	3317cW8j	2025-09-07 03:08:32.265766+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
469	2A3HPWER	2025-09-07 03:08:32.266805+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
471	2RGxZESd	2025-09-07 03:08:32.268454+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
473	3GPLQRtp	2025-09-07 03:08:32.271859+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	29	discard-pile	\N
475	XvAcxbDs	2025-09-07 03:08:32.273021+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
479	5oXQC3GF	2025-09-07 03:08:33.262175+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
481	4NL8UBJ4	2025-09-07 03:08:33.262947+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	36	discard-pile	\N
483	4iVAHUyq	2025-09-07 03:08:33.263848+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
485	CFYGo6Rn	2025-09-07 03:08:33.265004+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
487	5nsjtj3M	2025-09-07 03:08:33.266075+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
489	298iXzsX	2025-09-07 03:08:33.2672+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
491	tC5CJ9Pz	2025-09-07 03:08:33.268507+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
493	2R3emoKk	2025-09-07 03:08:34.260086+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	27	discard-pile	\N
495	2mCS8Jyk	2025-09-07 03:08:34.260869+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	31	discard-pile	\N
497	5rTqBXzQ	2025-09-07 03:08:34.261861+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	30	discard-pile	\N
499	2kfBuNCv	2025-09-07 03:08:34.262748+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	32	discard-pile	\N
501	QqFuotGe	2025-09-07 03:08:34.263673+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
503	G84hzddb	2025-09-07 03:08:34.26455+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
505	5ZvH64hc	2025-09-07 03:08:34.265338+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	28	discard-pile	\N
507	3QRjXr4d	2025-09-07 03:08:34.266171+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
509	2i7SnpRC	2025-09-07 03:08:34.267145+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
511	5tRyFA1j	2025-09-07 03:08:34.267981+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	39	discard-pile	\N
513	2yZseQFy	2025-09-07 03:08:35.260994+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	25	discard-pile	\N
515	5NjVn5Mu	2025-09-07 03:08:35.261836+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
517	2JpG38UY	2025-09-07 03:08:35.262847+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
519	31TgtpEn	2025-09-07 03:08:35.263894+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
521	So1ULEQb	2025-09-07 03:08:35.264848+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
523	5RAk1AXh	2025-09-07 03:08:35.265857+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	34	discard-pile	\N
525	4LSAZ7KB	2025-09-07 03:08:35.267006+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	34	discard-pile	\N
527	3ip7eCaU	2025-09-07 03:08:35.267943+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
529	1RFnGqiP	2025-09-07 03:08:35.268771+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	35	discard-pile	\N
530	43ncsEtV	2025-09-07 03:08:36.259705+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
532	3U8PziVG	2025-09-07 03:08:36.260942+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	24	discard-pile	\N
534	4LVLqQHc	2025-09-07 03:08:36.261762+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	31	discard-pile	\N
536	2yRoJKxV	2025-09-07 03:08:36.262704+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	31	discard-pile	\N
538	5N2yo5Tb	2025-09-07 03:08:36.263613+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	36	discard-pile	\N
540	23cuF2Um	2025-09-07 03:08:36.264571+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
542	4tJXkjRR	2025-09-07 03:08:36.265442+00	365151886	raydium-clmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	41	discard-pile	\N
544	3Qjgthj8	2025-09-07 03:08:36.26629+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	31	discard-pile	\N
546	4iiAHiKj	2025-09-07 03:08:37.259797+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	46	discard-pile	\N
548	2BWvucgn	2025-09-07 03:08:37.26102+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	28	discard-pile	\N
550	3tDgoqWM	2025-09-07 03:08:37.261725+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	32	discard-pile	\N
531	5oE19c3m	2025-09-07 03:08:36.260401+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
533	mQkFsZ6Q	2025-09-07 03:08:36.261378+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	33	discard-pile	\N
535	w7fNShzL	2025-09-07 03:08:36.262202+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
537	2AwRUusE	2025-09-07 03:08:36.26319+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
539	2srm8yK3	2025-09-07 03:08:36.264138+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
541	2hvGKmqE	2025-09-07 03:08:36.265007+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	35	discard-pile	\N
543	3X2x4CS3	2025-09-07 03:08:36.2658+00	365151886	phoenix-clob	spread-arbitrage	ORDER_BOOK-SPREAD_CAPTURE	6	0.00000000	0.00000000	\N	30	discard-pile	\N
545	5vjEBxVT	2025-09-07 03:08:36.266791+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	38	discard-pile	\N
547	5i5igW1q	2025-09-07 03:08:37.260443+00	365151886	meteora-dlmm	bin-arbitrage	BIN_TRANSITION-DLMM_SPECIAL	8	0.00000000	0.00000000	\N	37	discard-pile	\N
549	2UZVnj2T	2025-09-07 03:08:37.261377+00	365151886	meteora-dlmm	impact-arb	EXTRACTED-FROM_TX	15	0.00000000	0.00000000	\N	32	discard-pile	\N
551	D3HdWWfo	2025-09-20 01:19:22.997825+00	367976009	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	81	multi-venue-atomic	{"slot": 367976009, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "D3HdWWfouaDaqLLYppipFkx5W3iX4cfJCAiFdxUNypU1QwKG2bkRH83pzgdRqFizccdWSXLgqitWnknjGErnJH7", "timestamp": "2025-09-20T01:19:22.997721844Z", "processing_time_us": 144}
552	2Rs31jd1	2025-09-20 01:19:22.997964+00	367976009	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	57	multi-venue-atomic	{"slot": 367976009, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "2Rs31jd1x9BS7jSKvU2vms9TEN3zHuaLpN3CuzkNq1eGVJpvZngAwuneJTp98b9PS6ijSMdb12d8TtmuW9ar9uFU", "timestamp": "2025-09-20T01:19:22.997905785Z", "processing_time_us": 102}
553	4g9SQrkn	2025-09-20 01:19:22.998085+00	367976009	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	51	multi-venue-atomic	{"slot": 367976009, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4g9SQrknxcZRYBiTA2jofv2GdT7tZXqADAStuA4q6P8mjaYyYZiWianzwNWRSFfEJsfD6ReNz9jBVYE6xShyBG1a", "timestamp": "2025-09-20T01:19:22.998033613Z", "processing_time_us": 88}
554	4YDiDs5v	2025-09-20 01:19:22.999976+00	367976009	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	72	multi-venue-atomic	{"slot": 367976009, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4YDiDs5vU2uMZZf3dfNXSZEvRZftXSQ1eKko9fgW3PDuwDnwG3v38ixT58bXGEDkwuTQf8m46y5SDCC7DcaVQgg3", "timestamp": "2025-09-20T01:19:22.999914487Z", "processing_time_us": 114}
555	48sKPyn6	2025-09-20 01:19:23.000803+00	367976009	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	82	multi-venue-atomic	{"slot": 367976009, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "48sKPyn6PKckSnTxVNvNMfhTiy4HzZyu81dC4MgAGRjRtjocwWsTDtJdteL6SFx415AmiwLUG6CfSrkDYrJSwmGJ", "timestamp": "2025-09-20T01:19:23.000723017Z", "processing_time_us": 130}
556	4f2xWhto	2025-09-20 01:19:23.192787+00	367976009	meteora-dlmm	single-venue	SOL/MSOL	4	0.00000000	0.00000000	\N	73	multi-venue-atomic	{"slot": 367976009, "token_a": "SOL", "token_b": "MSOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4f2xWhtoU38KYvKmn2JBXQhroTqATkHLRfQkxCiEQ3WVbGWXzQFPFsLEFMLQQUpyqYfYfi4h1Ac7FWYBsmpMt7CN", "timestamp": "2025-09-20T01:19:23.192711182Z", "processing_time_us": 129}
557	5NzL6gMK	2025-09-20 01:19:23.389826+00	367976010	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	80	multi-venue-atomic	{"slot": 367976010, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "5NzL6gMKYTvVdbkUY7ryWN52KmGbpoE1GSPz4Npdt68C6sN3JNDBKacGtdfwpJ6U1ywpTofkgrtk4EjshSKiVu6b", "timestamp": "2025-09-20T01:19:23.389693267Z", "processing_time_us": 181}
558	4VnzjKgE	2025-09-20 01:19:23.390622+00	367976010	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	50	multi-venue-atomic	{"slot": 367976010, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4VnzjKgExRXcKrUiaKGU2dT9BFDcD9n5PwcMkVAGzqXTM3CFG6pBKbwDp6nfU5zrXuQ23CASfRMpsw5gv7K2SpF6", "timestamp": "2025-09-20T01:19:23.390576596Z", "processing_time_us": 83}
559	uvH8qaNp	2025-09-20 01:19:23.391482+00	367976010	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	50	multi-venue-atomic	{"slot": 367976010, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "uvH8qaNpVQunkzMuV4TnLML2Urwk6Lu9PMvGYooVUe4foVyM7GMxQFYJHsthyfUb1iE3bnwnTjpdwLaGrKUv5xF", "timestamp": "2025-09-20T01:19:23.391435001Z", "processing_time_us": 87}
560	4RWCK1V9	2025-09-20 01:19:23.447477+00	367976010	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	63	multi-venue-atomic	{"slot": 367976010, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4RWCK1V9pyabinQ7V1BNCKPshKhmXhBkxYWFBtJcfj8JLuZwWveECkr5DW2yH7MeQU9yiaZMTLjKiv7mwyoKqybD", "timestamp": "2025-09-20T01:19:23.447417886Z", "processing_time_us": 104}
561	2cSbYJFW	2025-09-20 01:19:23.559943+00	367976010	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	81	multi-venue-atomic	{"slot": 367976010, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "2cSbYJFWFqbu71MkfKdeXcRVNctATQQUcRoYe7C9NnjJm64w78vUQbbNsEEknqeZYoLaPwyWuDaZEx8xPnD3cS1r", "timestamp": "2025-09-20T01:19:23.559865943Z", "processing_time_us": 125}
562	4Aa7zTFo	2025-09-20 01:19:23.560739+00	367976010	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	45	multi-venue-atomic	{"slot": 367976010, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4Aa7zTFo7imWzTLrp8WT3ugRE92PjruHwcpd9eCaNwGkAYxSbfdaqiFz6HcxD9q5PabTH3SYkLuomrvyXbYd4SXY", "timestamp": "2025-09-20T01:19:23.560691542Z", "processing_time_us": 83}
563	qnMLS5vH	2025-09-20 01:19:23.562403+00	367976010	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	45	multi-venue-atomic	{"slot": 367976010, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "qnMLS5vHgpCCsw3qcNhm3xDFSkoN3eGmAf3PjhEquXBJQShBozwYWV9uH3kAbA6LEyi72oc6gzsSBum2VLiQhg8", "timestamp": "2025-09-20T01:19:23.562360004Z", "processing_time_us": 78}
564	61midRZE	2025-09-20 01:19:23.728783+00	367976011	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	64	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "61midRZEmWhfR9BNe4rh96BFVHoMaaJicubxSvvHrmtrkMKaXTwYSqjSCkfNS2jH2uPPCcMFTfJzE3bEv8gMafar", "timestamp": "2025-09-20T01:19:23.728711752Z", "processing_time_us": 117}
565	bGinpke6	2025-09-20 01:19:23.755048+00	367976011	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	47	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "bGinpke6qSrdi2fTWvVGfVCw8xU4GP4fbEDMPhSKTeBRBw9LttUh1gtV3MQxZaiLNAEqo5Nqe3f1G6naMqbbAHr", "timestamp": "2025-09-20T01:19:23.754999416Z", "processing_time_us": 75}
566	3aV8PL96	2025-09-20 01:19:23.7784+00	367976011	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	92	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "3aV8PL966U8ox2uZAMRUtsSZNoTiE3p95Dg6eYU6GdzezunwaRJXwzXPm3NELnNbbst2cfiWbWYdNxbDBjRpRmWP", "timestamp": "2025-09-20T01:19:23.778301994Z", "processing_time_us": 158}
567	rghXb7bv	2025-09-20 01:19:23.782732+00	367976011	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	92	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "rghXb7bvze7JMUiB5DYyhdk7XpMGtfcHSbN5qRcaqSBMhVzCYeL2t8BxcgiAK83WAbMzUPWspgHZuFuQgAQxgRt", "timestamp": "2025-09-20T01:19:23.782644837Z", "processing_time_us": 146}
568	2KVSCFiy	2025-09-20 01:19:23.786604+00	367976011	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	48	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "2KVSCFiyyWAB3fPFyfp51RAJHsrKyqbt5NN7xeB9Exfq9syAVUr1eUjhRcBrCq5VeV5kydRVvtYNcfgxV4M7Ft5h", "timestamp": "2025-09-20T01:19:23.786553815Z", "processing_time_us": 89}
569	3bJPZ2vp	2025-09-20 01:19:23.78747+00	367976011	meteora-dlmm	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	58	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "meteora-dlmm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "3bJPZ2vpPa8ARZxYn5nUwSxLZL6BG6uZHTDExz9MwfaTcSsqn2aMjTAqoLpJs6rGA4NT97ejEDPRcPQiAW7JAhLf", "timestamp": "2025-09-20T01:19:23.787411383Z", "processing_time_us": 97}
570	4wwqEXRK	2025-09-20 01:19:23.901441+00	367976011	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	72	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4wwqEXRKi4CbWFXDDQMqqpnKjVRiqMPsxx7GM3Yq1zntvPoxbEVAnyBDh29r65ZZMJqoGEHGxRYz4ZoJEVP1fXf9", "timestamp": "2025-09-20T01:19:23.901376027Z", "processing_time_us": 113}
571	9NxooSbY	2025-09-20 01:19:23.949567+00	367976011	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	96	multi-venue-atomic	{"slot": 367976011, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "9NxooSbYo6cqRXDy2pKP8axpnsDJs3PDVE2DpaATEGfS3PeBZj3fS7DNqwNvByggoU4Sc4p9Wj8HCKt3UkkRKQz", "timestamp": "2025-09-20T01:19:23.949478200Z", "processing_time_us": 149}
572	39M1RsKi	2025-09-20 01:19:24.361566+00	367976012	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	83	multi-venue-atomic	{"slot": 367976012, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "39M1RsKiKCcbkfqkwJQaKL9cq2STzTBGNxJ7hKx2H3FEhpgc1TMTFuJu14ygkQFnKGw1ReH5ydvtYNRb5PtvyM4U", "timestamp": "2025-09-20T01:19:24.361495271Z", "processing_time_us": 125}
573	2NDYKZLV	2025-09-20 01:19:24.36277+00	367976012	phoenix-clob	single-venue	USDC/SOL	2	0.00000000	0.00000000	\N	74	multi-venue-atomic	{"slot": 367976012, "token_a": "USDC", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "2NDYKZLVoQfMMhpxswJxUHxwXkuaYWcMdbQ6kgT5GZk5weGPPUebdHaNZ8PNBY5rCS8JJQgkRsD9vVdx5WpKQikv", "timestamp": "2025-09-20T01:19:24.362689158Z", "processing_time_us": 130}
574	4TJfPqW7	2025-09-20 01:19:24.363164+00	367976012	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	70	multi-venue-atomic	{"slot": 367976012, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4TJfPqW716hTJuy7DQMnwZUfNDzG3aemVEbJNyi7eHD3ERSJ3C1t9pX9FZ5anzcs2cCwPL6cqF9dFR4SWnUETt2Z", "timestamp": "2025-09-20T01:19:24.363099280Z", "processing_time_us": 113}
575	5bxPHa2k	2025-09-20 01:19:24.40251+00	367976012	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	69	multi-venue-atomic	{"slot": 367976012, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "5bxPHa2kqp4yGCwvynD499eUHqL6iVczcs6zwJzZUzLC1G5NrxJbeMfhuBdVkZJ1WrivEPPxAUfvexspGK1b89HL", "timestamp": "2025-09-20T01:19:24.402447416Z", "processing_time_us": 115}
576	tRVkwp8f	2025-09-20 01:19:24.568389+00	367976013	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	101	multi-venue-atomic	{"slot": 367976013, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "tRVkwp8f1cQXcSyddgkYjsejF9aJiYc8YZeRPLqYjKfV2wgNHv7pejCMo8FqHoatSNyUbXYWdGSPh85jVjottbF", "timestamp": "2025-09-20T01:19:24.568292001Z", "processing_time_us": 162}
577	4CfhZvba	2025-09-20 01:19:24.655949+00	367976013	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	75	multi-venue-atomic	{"slot": 367976013, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4CfhZvbaR8d6UVjZXdbFBBngHjDbVZVhX2YW99rjq6ss1EYJWVaud8EvMc268ZCQRX6rcbc52pTQG2nxzDeWv3EP", "timestamp": "2025-09-20T01:19:24.655883730Z", "processing_time_us": 113}
578	4hY8wHvV	2025-09-20 01:19:24.982145+00	367976014	phoenix-clob	single-venue	USDT/SOL	3	0.00000000	0.00000000	\N	89	multi-venue-atomic	{"slot": 367976014, "token_a": "USDT", "token_b": "SOL", "venue_a": "phoenix-clob", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4hY8wHvVC9bFn8SvuqiKg2ByDr1d8uJw4nQd96MtTBWyhUozbQoR2Zjmiz2e3rbETTTwz75N2PFE6eu7p7ztXjak", "timestamp": "2025-09-20T01:19:24.982064876Z", "processing_time_us": 136}
579	4eigrUxM	2025-09-20 01:19:26.33362+00	367976017	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	66	multi-venue-atomic	{"slot": 367976017, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "4eigrUxMbqcyh8kf2q5ivDmVyaTVwBwqtw6FrouSakp5aSkdkeWEcT4SUoaNWvFuiAyoZ2QzCumoyRVQ2ogr4WzV", "timestamp": "2025-09-20T01:19:26.333557037Z", "processing_time_us": 117}
580	3TnMhg6d	2025-09-20 01:19:26.340598+00	367976017	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	62	multi-venue-atomic	{"slot": 367976017, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "3TnMhg6dMrGKeRoYUQ13gSC6opLA1X3m9yrkanSzJGhRuuWLG1YHkztJmnJJPhSAjVB3Md2Vao85QVRoXg3hDJ24", "timestamp": "2025-09-20T01:19:26.340539885Z", "processing_time_us": 112}
581	5Si4Dq18	2025-09-20 01:19:26.342852+00	367976017	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	73	multi-venue-atomic	{"slot": 367976017, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5Si4Dq18qFyaeGd393EaUMtRwva1e9DLEoudye9hTfEqJspf4YEubUGGV1Y9VSsthQ7aBJcWiakC4ECFU86m2sWn", "timestamp": "2025-09-20T01:19:26.342790510Z", "processing_time_us": 122}
583	3zLvoHYQ	2025-09-20 01:19:29.241548+00	367976024	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	94	multi-venue-atomic	{"slot": 367976024, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "3zLvoHYQTLqJ4o8pPCx9FoPZzP7oNwcr6S4g15DZhXCXXncge7jHFQidDUQTrfT7QqcqXSwsC1ax1oyxwFBSh3Yg", "timestamp": "2025-09-20T01:19:29.241457151Z", "processing_time_us": 150}
584	Lmb36UPA	2025-09-20 01:19:29.251357+00	367976024	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	85	multi-venue-atomic	{"slot": 367976024, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "Lmb36UPA3JKTSX2kgWcvdurxrRxoLhDezL5RP9r4LApVt795uppn6to1aRMeEC5APKjMsp3AbdwU4fxqm6sPHTx", "timestamp": "2025-09-20T01:19:29.251274374Z", "processing_time_us": 146}
587	5ECz4oxd	2025-09-20 01:19:29.263388+00	367976024	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	87	multi-venue-atomic	{"slot": 367976024, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5ECz4oxdzQCuHyhHfiGmDFp8v77vqKzhVvsD1AFicmuGJcW2vtVRd7hNGLjPBpbmdbZ2giYUoog4XBYAp53EGcdK", "timestamp": "2025-09-20T01:19:29.263311530Z", "processing_time_us": 147}
588	4tPpDrkh	2025-09-20 01:19:29.266365+00	367976024	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	93	multi-venue-atomic	{"slot": 367976024, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "4tPpDrkh49Fgm53ZiiB8W51eCNXdsf6ZDwFbp3RKgEHdLVkv2ZJuHJ45uqrorLDrtXxraMTXVnwYB7LEu1vsRvM6", "timestamp": "2025-09-20T01:19:29.266280131Z", "processing_time_us": 154}
589	3eFrfFQv	2025-09-20 01:19:29.266517+00	367976024	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	74	multi-venue-atomic	{"slot": 367976024, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "3eFrfFQvt97wP1EMvz2UHoKm1Xp2s4j4haKKrQS6URzRCp8iGdm8GeecPJpgnDhpjetHooVEhX9Ut5vTX7QcpFCp", "timestamp": "2025-09-20T01:19:29.266455811Z", "processing_time_us": 123}
593	48gtjZNX	2025-09-20 01:19:30.159118+00	367976027	whirlpool	single-venue	SOL/MSOL	4	0.00000000	0.00000000	\N	133	multi-venue-atomic	{"slot": 367976027, "token_a": "SOL", "token_b": "MSOL", "venue_a": "whirlpool", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "48gtjZNXKucLzGNWhXTMNDoWYf8L8Z7zb4LMjZ83NrDxZyhcbV1xSKgCBRqZCRsmSrBvsqh3oQY8Lk4BgBohUsCD", "timestamp": "2025-09-20T01:19:30.158985295Z", "processing_time_us": 186}
594	57VpGXvm	2025-09-20 01:19:31.725017+00	367976031	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	83	multi-venue-atomic	{"slot": 367976031, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "57VpGXvmmD36AorkzP5xtvATCeewXJZTuh46raoWU7hWczM3TPxdNtqj14Nmr4Emx2mn7YrCkdZrH3DTmfjAhH6S", "timestamp": "2025-09-20T01:19:31.724937669Z", "processing_time_us": 138}
596	316YR9ca	2025-09-20 01:19:31.768116+00	367976031	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	75	multi-venue-atomic	{"slot": 367976031, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "316YR9caH8iuWYi6jNjBK699v1xttRDqtduSFD3kUBJg7nEV6vgW7fVf1jpEMWHfcFkjahMHnBMvz7BrSmNQ3AVJ", "timestamp": "2025-09-20T01:19:31.768042736Z", "processing_time_us": 126}
598	5hGP8eYx	2025-09-20 01:19:32.114035+00	367976032	whirlpool	single-venue	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	68	multi-venue-atomic	{"slot": 367976032, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "5hGP8eYx6HkAF3vPnFUprhs5dTFbW2gLuvyW74WBr17VywstZ5FJPryQVMUjaC1hSRV15XUbsAVJgwUTn56RkPK5", "timestamp": "2025-09-20T01:19:32.113969034Z", "processing_time_us": 113}
600	5oDsxKQV	2025-09-20 01:19:32.708857+00	367976033	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	104	multi-venue-atomic	{"slot": 367976033, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5oDsxKQV3uwMtLgeN3konuCmMYAiKbuYHKgKbmwuvduK8PKaXStptLDHT5BGN3FzREzQe8nVoZURhy2WKNqrewdm", "timestamp": "2025-09-20T01:19:32.708763427Z", "processing_time_us": 164}
601	5HUGPPt9	2025-09-20 01:19:32.709018+00	367976033	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	77	multi-venue-atomic	{"slot": 367976033, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5HUGPPt9tBJgedgtPJp3b4uWawhPXZP11ZqcajjM6vsGzQAKTupQuqxf4mzzoQ5mt3uL8RxcB31kgtfdXksAkXt2", "timestamp": "2025-09-20T01:19:32.708944060Z", "processing_time_us": 131}
604	YFjybLpq	2025-09-20 01:19:33.08217+00	367976034	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	84	multi-venue-atomic	{"slot": 367976034, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "YFjybLpqhNwtT6AruLCz51WhvEhdL3efmMuGLfyWmPQYDW4sGMTSCHxeTFwCXP4eYBmDa5ThbEU4GmAjH6Kxmm9", "timestamp": "2025-09-20T01:19:33.082093069Z", "processing_time_us": 138}
606	oYscA4bg	2025-09-20 01:19:34.312925+00	367976038	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	102	multi-venue-atomic	{"slot": 367976038, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "oYscA4bgfjS5tbVugbUpLL5VGxdp43PpiijhQinH1RxnMGYZ9frwfXksshACHr2G9L72tnAWg2e2qTUKCYZCM2Z", "timestamp": "2025-09-20T01:19:34.312827248Z", "processing_time_us": 167}
608	4NpHV8qN	2025-09-20 01:19:36.183644+00	367976042	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	69	multi-venue-atomic	{"slot": 367976042, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "4NpHV8qNzmztr3ZwdHJpZpiZ4c94mXgdZsaoDqTX6DfpDsWPcSv11pcjcREYavVaLrpVZqcBj3T4LVNxxN9W5oe6", "timestamp": "2025-09-20T01:19:36.183576861Z", "processing_time_us": 119}
609	s33JchaS	2025-09-20 01:19:36.18542+00	367976042	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	92	multi-venue-atomic	{"slot": 367976042, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "s33JchaSWTYWi7am16KyfkUhmfqxMKkRm8BT8U5oyCqJ8PYeCwCCxnV3jtuC5tHugUHkFNbSbRKmTmvVtxA3qFc", "timestamp": "2025-09-20T01:19:36.185360498Z", "processing_time_us": 139}
612	4sF5VB7t	2025-09-20 01:19:36.454807+00	367976043	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	111	multi-venue-atomic	{"slot": 367976043, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "4sF5VB7t6b4YDh7HXM5k5MewPfZmyMAcFxEmQbP3d2b5MEyMjxB4RnUvBMKCrnrLKUWRbTmcx2YpxUvEhjVPfC1i", "timestamp": "2025-09-20T01:19:36.454693275Z", "processing_time_us": 180}
613	5tdyCcWW	2025-09-20 01:19:37.475028+00	367976045	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	80	multi-venue-atomic	{"slot": 367976045, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5tdyCcWWDfZoDPkGwqoARYXT8sJGVmJv8wW2Z8njeR4UtutPcQq5qRcAhDVZhrQxCnGEzHgyYD1LM23TBzqgR7tt", "timestamp": "2025-09-20T01:19:37.474951831Z", "processing_time_us": 133}
615	8WPtrSQo	2025-09-20 01:19:37.524419+00	367976046	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	99	multi-venue-atomic	{"slot": 367976046, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "8WPtrSQofE6bmaXpQcT4uY2xWHcLSQiNNscBGxA7cTKxdkwVf5DUEo3zxsRhvC35gTqNBUJdhMfeLdu1GQW8awc", "timestamp": "2025-09-20T01:19:37.524308875Z", "processing_time_us": 178}
616	4nRfojQD	2025-09-20 01:19:37.661334+00	367976046	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	85	multi-venue-atomic	{"slot": 367976046, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "4nRfojQDXXNg1SAMHKWKD9Q5uXRz6LBh1bFwNwjMHmG3LALvZDUzisxdESE8XeyUm3oVPr7R4NbrMkGUPJgUad7W", "timestamp": "2025-09-20T01:19:37.661251016Z", "processing_time_us": 146}
618	5XcBi1TF	2025-09-20 01:19:37.872906+00	367976046	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	76	multi-venue-atomic	{"slot": 367976046, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5XcBi1TFZQDRdnxxhPPCvSUq3i2iWrDgurefzzTqNrsYB9Zj3u4wJaYTXctHqHVkqJUPmF92xH1YgNUi1Wy7BReG", "timestamp": "2025-09-20T01:19:37.872832154Z", "processing_time_us": 124}
620	4AFvYuKe	2025-09-20 01:19:39.647865+00	367976051	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	82	multi-venue-atomic	{"slot": 367976051, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "4AFvYuKeNpxjAuWFaATopkPKFNgVJRDwnB1s6hMvT8Hh5oNYVX69xB3u5iim7pnVaernFALo8nje5ViYqXteCuZJ", "timestamp": "2025-09-20T01:19:39.647798426Z", "processing_time_us": 131}
621	4fxXLf9F	2025-09-20 01:19:39.653701+00	367976051	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	112	multi-venue-atomic	{"slot": 367976051, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "4fxXLf9FJoP2J3bdZu8T7nm4Nt7aDsWZ7MKaasbR71YBH65kQYkQt6avt8B8tEJZuftocdSXF9Dc65XEupE5aP3p", "timestamp": "2025-09-20T01:19:39.653591379Z", "processing_time_us": 161}
622	3749frAc	2025-09-20 01:19:39.655446+00	367976051	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	66	multi-venue-atomic	{"slot": 367976051, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "3749frAcxY9bNN5L4VmKDeoZ4JAhPZUPLAXcivukRtv9WZfiK5bZkfQ3ijJ1mmqKu52YDscRUTDQTFTpr4zxnH7L", "timestamp": "2025-09-20T01:19:39.655383276Z", "processing_time_us": 114}
625	5hCJDtCt	2025-09-20 01:19:39.682854+00	367976051	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	75	multi-venue-atomic	{"slot": 367976051, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5hCJDtCtNH6Z1QtNaJBrujK9nFQm1rPkYm1jxaBohCEeyxix7QTciNyZVL3mtCH22sT6RmuSMy69MwSYphmEbyTg", "timestamp": "2025-09-20T01:19:39.682787354Z", "processing_time_us": 124}
627	LSJry4XQ	2025-09-20 01:19:39.789272+00	367976051	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	86	multi-venue-atomic	{"slot": 367976051, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "LSJry4XQmaZCvZ9oBDSsL2Q7KWUi43Wy5AgUm1KVBZbiBMgESnsVAKYqT2epAPaEDhQv3CVWf4miQSsPa9uQ7zr", "timestamp": "2025-09-20T01:19:39.789185845Z", "processing_time_us": 145}
629	2K5u18dn	2025-09-20 01:19:39.897001+00	367976051	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	98	multi-venue-atomic	{"slot": 367976051, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "2K5u18dnAqThXCA5cbPzij9HpskgKSziF7bDTa6s6YfmDsPsxVVDs9QULudeLLKeY6v166N4Q9mn7WUveJKQc9Xu", "timestamp": "2025-09-20T01:19:39.896906255Z", "processing_time_us": 160}
630	3PjDLYJu	2025-09-20 01:19:40.168501+00	367976052	raydium-amm	single-venue	SOL/MSOL	4	0.00000000	0.00000000	\N	57	multi-venue-atomic	{"slot": 367976052, "token_a": "SOL", "token_b": "MSOL", "venue_a": "raydium-amm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "3PjDLYJuUYqRuncQGwQTSuvcied71WgTMeFbQ9MguXRWrk1GdTBZ4n1sWP5RiKPpoVhLWyK4QuzQHidCiar9d4AP", "timestamp": "2025-09-20T01:19:40.168443382Z", "processing_time_us": 92}
631	wfqYzXdx	2025-09-20 01:19:42.135196+00	367976057	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	85	multi-venue-atomic	{"slot": 367976057, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "wfqYzXdxQH4v1RiozsoYcuqLHqSLmVDL7AbhAMN8fa9p7DrWcaKgKnvBM1uUxmupSNytN2uCmsDufz4dQmpp7Cj", "timestamp": "2025-09-20T01:19:42.135114414Z", "processing_time_us": 136}
632	3k69sfWs	2025-09-20 01:19:42.136442+00	367976057	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	69	multi-venue-atomic	{"slot": 367976057, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "3k69sfWsxcfRB3h6tEjWxVrgKomhEZYsFpexte9G5C3x9pwr4GJMEZPH8m8JzAyjHfwVBzxuzPyiiBzLAVLZBgGw", "timestamp": "2025-09-20T01:19:42.136377369Z", "processing_time_us": 117}
633	3yzybfwb	2025-09-20 01:19:42.138736+00	367976057	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	66	multi-venue-atomic	{"slot": 367976057, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "3yzybfwbRFwqdoTWmtHn5whNYpQo3th2DMrYXijstGmEeTZ8Be4Tox1dihPzwZQEnNmHQcBcH34KeiJG96J39FkQ", "timestamp": "2025-09-20T01:19:42.138676217Z", "processing_time_us": 112}
634	5cqFp8zQ	2025-09-20 01:19:42.13886+00	367976057	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	54	multi-venue-atomic	{"slot": 367976057, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "5cqFp8zQWBGUi1Sy3N634gT5ogMnpBdij2RvvmtKrwmXeGYTUnFWQQ3edjE1w2HTohMtrSfuHZzzWV2omXXiH74q", "timestamp": "2025-09-20T01:19:42.138807927Z", "processing_time_us": 97}
638	5UhKctNn	2025-09-20 01:19:42.14968+00	367976057	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	73	multi-venue-atomic	{"slot": 367976057, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "5UhKctNnukNt4CaZCoQaKnH9G65Ph9fsjEZV7axSBH3g5sekhaX1cU1368Rqeb76hioiHbKRXgpHw3eWoGwaZDfk", "timestamp": "2025-09-20T01:19:42.149612388Z", "processing_time_us": 122}
639	55RHkwoV	2025-09-20 01:19:42.202703+00	367976057	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	95	multi-venue-atomic	{"slot": 367976057, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "55RHkwoVMb1J4C2m1HJKjsoBK9ixyzdfosWFFVHTxPCWnvnX19dM6uDARpM61zDUpnGGGYLwmk8vABVtYAfpLvmz", "timestamp": "2025-09-20T01:19:42.202619256Z", "processing_time_us": 156}
640	5NTMojdc	2025-09-20 01:19:42.776214+00	367976059	whirlpool	raydium-clmm	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	97	multi-venue-atomic	{"slot": 367976059, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "whirlpool", "venue_b": "raydium-clmm", "strategy": "multi-venue-atomic", "signature": "5NTMojdcc3vRcD1TTJmEn7EQWsUNECCL8RdAX5dNFbZw3YtM2zy8w89YRiobj8MWcvnaQ5FDLRRd533zX9tpC5JL", "timestamp": "2025-09-20T01:19:42.776128090Z", "processing_time_us": 157}
641	2NcT445r	2025-09-20 01:19:42.918484+00	367976059	meteora-dlmm	whirlpool	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	94	multi-venue-atomic	{"slot": 367976059, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "meteora-dlmm", "venue_b": "whirlpool", "strategy": "multi-venue-atomic", "signature": "2NcT445rg8BjiV3y1uxrxmPPSNNtQNNfuYJEdHtKvBD5cAPDDwzsNqiDrsp3guSFAyU8fVA6CDdb3ebzgThEvhB8", "timestamp": "2025-09-20T01:19:42.918402624Z", "processing_time_us": 147}
643	4B62Hgbo	2025-09-20 01:19:43.506119+00	367976061	raydium-amm	single-venue	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	73	multi-venue-atomic	{"slot": 367976061, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "raydium-amm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "4B62HgboV1ScJPbYYCPB8xP1mPqRvdZZzKYhpgzWdCt7piT93M2z7CphcU3uKdM9JouzjG63LTXVFUxBdES8TiNh", "timestamp": "2025-09-20T01:19:43.506049213Z", "processing_time_us": 121}
644	MASEUGuR	2025-09-20 01:19:44.204723+00	367976063	raydium-amm	single-venue	TOKEN_A/TOKEN_B	6	0.00000000	0.00000000	\N	98	multi-venue-atomic	{"slot": 367976063, "token_a": "TOKEN_A", "token_b": "TOKEN_B", "venue_a": "raydium-amm", "venue_b": "single-venue", "strategy": "multi-venue-atomic", "signature": "MASEUGuRsyQV9YjeeZ4186ZyRudCzPRcrArsb3jozvierqDa5ZxSDooBVfC8jy3VDubLXZ9NQBQxDvmVuLEvxB9", "timestamp": "2025-09-20T01:19:44.204631011Z", "processing_time_us": 161}
\.


--
-- TOC entry 3462 (class 0 OID 16419)
-- Dependencies: 219
-- Data for Name: execution_results; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.execution_results (id, opportunity_id, "timestamp", executed, success, actual_profit_bps, execution_time_us, gas_cost_sol, slippage_bps, failure_reason, transaction_signature, bundle_id, raw_result) FROM stdin;
1	orca_meteora_1	2025-09-06 21:39:13.400816+00	t	t	11	1200	\N	\N	\N	\N	\N	{}
2	phoenix_raydium_1	2025-09-06 21:41:13.400816+00	t	t	7	850	\N	\N	\N	\N	\N	{}
3	meteora_orca_1	2025-09-06 21:43:13.400816+00	t	f	\N	2100	\N	\N	\N	\N	\N	{"error": "slippage_exceeded"}
4	D3HdWWfo	2025-09-20 01:19:22.997825+00	t	t	3	144	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 81, "processing_time_us": 144}
5	2Rs31jd1	2025-09-20 01:19:22.997964+00	t	t	3	102	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 57, "processing_time_us": 102}
6	4g9SQrkn	2025-09-20 01:19:22.998085+00	t	t	3	88	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 51, "processing_time_us": 88}
7	4YDiDs5v	2025-09-20 01:19:22.999976+00	t	t	3	114	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 72, "processing_time_us": 114}
8	48sKPyn6	2025-09-20 01:19:23.000803+00	t	t	3	130	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 82, "processing_time_us": 130}
9	4f2xWhto	2025-09-20 01:19:23.192787+00	t	t	4	129	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 73, "processing_time_us": 129}
10	5NzL6gMK	2025-09-20 01:19:23.389826+00	t	t	3	181	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 80, "processing_time_us": 181}
11	4VnzjKgE	2025-09-20 01:19:23.390622+00	t	t	3	83	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 50, "processing_time_us": 83}
12	uvH8qaNp	2025-09-20 01:19:23.391482+00	t	t	3	87	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 50, "processing_time_us": 87}
13	4RWCK1V9	2025-09-20 01:19:23.447477+00	t	t	3	104	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 63, "processing_time_us": 104}
14	2cSbYJFW	2025-09-20 01:19:23.559943+00	t	t	3	125	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 81, "processing_time_us": 125}
15	4Aa7zTFo	2025-09-20 01:19:23.560739+00	t	t	3	83	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 45, "processing_time_us": 83}
16	qnMLS5vH	2025-09-20 01:19:23.562403+00	t	t	3	78	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 45, "processing_time_us": 78}
17	61midRZE	2025-09-20 01:19:23.728783+00	t	t	3	117	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 64, "processing_time_us": 117}
18	bGinpke6	2025-09-20 01:19:23.755048+00	t	t	3	75	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 47, "processing_time_us": 75}
19	3aV8PL96	2025-09-20 01:19:23.7784+00	t	t	3	158	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 92, "processing_time_us": 158}
20	rghXb7bv	2025-09-20 01:19:23.782732+00	t	t	3	146	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 92, "processing_time_us": 146}
21	2KVSCFiy	2025-09-20 01:19:23.786604+00	t	t	3	89	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 48, "processing_time_us": 89}
22	3bJPZ2vp	2025-09-20 01:19:23.78747+00	t	t	3	97	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 58, "processing_time_us": 97}
23	4wwqEXRK	2025-09-20 01:19:23.901441+00	t	t	3	113	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 72, "processing_time_us": 113}
24	9NxooSbY	2025-09-20 01:19:23.949567+00	t	t	3	149	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 96, "processing_time_us": 149}
25	39M1RsKi	2025-09-20 01:19:24.361566+00	t	t	3	125	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 83, "processing_time_us": 125}
26	2NDYKZLV	2025-09-20 01:19:24.36277+00	t	t	2	130	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 74, "processing_time_us": 130}
27	4TJfPqW7	2025-09-20 01:19:24.363164+00	t	t	3	113	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 70, "processing_time_us": 113}
28	5bxPHa2k	2025-09-20 01:19:24.40251+00	t	t	3	115	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 69, "processing_time_us": 115}
29	tRVkwp8f	2025-09-20 01:19:24.568389+00	t	t	3	162	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 101, "processing_time_us": 162}
30	4CfhZvba	2025-09-20 01:19:24.655949+00	t	t	3	113	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 75, "processing_time_us": 113}
31	4hY8wHvV	2025-09-20 01:19:24.982145+00	t	t	3	136	\N	\N	\N	\N	\N	{"stream_id": 3, "arbitrage_time_us": 89, "processing_time_us": 136}
32	4eigrUxM	2025-09-20 01:19:26.33362+00	t	t	6	117	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 66, "processing_time_us": 117}
33	3TnMhg6d	2025-09-20 01:19:26.340598+00	t	t	6	112	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 62, "processing_time_us": 112}
34	5Si4Dq18	2025-09-20 01:19:26.342852+00	t	t	6	122	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 73, "processing_time_us": 122}
35	4eigrUxM	2025-09-20 01:19:26.342968+00	t	t	6	98	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 56, "processing_time_us": 98}
36	3zLvoHYQ	2025-09-20 01:19:29.241548+00	t	t	6	150	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 94, "processing_time_us": 150}
37	Lmb36UPA	2025-09-20 01:19:29.251357+00	t	t	6	146	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 85, "processing_time_us": 146}
38	3zLvoHYQ	2025-09-20 01:19:29.251828+00	t	t	6	136	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 81, "processing_time_us": 136}
39	Lmb36UPA	2025-09-20 01:19:29.262775+00	t	t	6	194	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 115, "processing_time_us": 194}
40	5ECz4oxd	2025-09-20 01:19:29.263388+00	t	t	6	147	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 87, "processing_time_us": 147}
41	4tPpDrkh	2025-09-20 01:19:29.266365+00	t	t	6	154	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 93, "processing_time_us": 154}
42	3eFrfFQv	2025-09-20 01:19:29.266517+00	t	t	6	123	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 74, "processing_time_us": 123}
43	5ECz4oxd	2025-09-20 01:19:29.270093+00	t	t	6	154	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 91, "processing_time_us": 154}
44	4tPpDrkh	2025-09-20 01:19:29.273579+00	t	t	6	154	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 90, "processing_time_us": 154}
45	3eFrfFQv	2025-09-20 01:19:29.273737+00	t	t	6	128	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 72, "processing_time_us": 128}
46	48gtjZNX	2025-09-20 01:19:30.159118+00	t	t	4	186	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 133, "processing_time_us": 186}
47	57VpGXvm	2025-09-20 01:19:31.725017+00	t	t	6	138	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 83, "processing_time_us": 138}
48	57VpGXvm	2025-09-20 01:19:31.734649+00	t	t	6	145	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 84, "processing_time_us": 145}
49	316YR9ca	2025-09-20 01:19:31.768116+00	t	t	6	126	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 75, "processing_time_us": 126}
50	316YR9ca	2025-09-20 01:19:31.783235+00	t	t	6	154	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 91, "processing_time_us": 154}
51	5hGP8eYx	2025-09-20 01:19:32.114035+00	t	t	6	113	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 68, "processing_time_us": 113}
52	5hGP8eYx	2025-09-20 01:19:32.118407+00	t	t	6	89	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 53, "processing_time_us": 89}
53	5oDsxKQV	2025-09-20 01:19:32.708857+00	t	t	6	164	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 104, "processing_time_us": 164}
54	5HUGPPt9	2025-09-20 01:19:32.709018+00	t	t	6	131	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 77, "processing_time_us": 131}
55	5oDsxKQV	2025-09-20 01:19:32.716394+00	t	t	6	135	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 78, "processing_time_us": 135}
56	5HUGPPt9	2025-09-20 01:19:32.716545+00	t	t	6	122	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 69, "processing_time_us": 122}
57	YFjybLpq	2025-09-20 01:19:33.08217+00	t	t	6	138	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 84, "processing_time_us": 138}
58	YFjybLpq	2025-09-20 01:19:33.090373+00	t	t	6	143	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 87, "processing_time_us": 143}
59	oYscA4bg	2025-09-20 01:19:34.312925+00	t	t	6	167	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 102, "processing_time_us": 167}
60	oYscA4bg	2025-09-20 01:19:34.3249+00	t	t	6	138	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 82, "processing_time_us": 138}
61	4NpHV8qN	2025-09-20 01:19:36.183644+00	t	t	6	119	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 69, "processing_time_us": 119}
62	s33JchaS	2025-09-20 01:19:36.18542+00	t	t	6	139	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 92, "processing_time_us": 139}
63	4NpHV8qN	2025-09-20 01:19:36.18569+00	t	t	6	107	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 61, "processing_time_us": 107}
64	s33JchaS	2025-09-20 01:19:36.187703+00	t	t	6	113	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 65, "processing_time_us": 113}
65	4sF5VB7t	2025-09-20 01:19:36.454807+00	t	t	6	180	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 111, "processing_time_us": 180}
66	5tdyCcWW	2025-09-20 01:19:37.475028+00	t	t	6	133	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 80, "processing_time_us": 133}
67	5tdyCcWW	2025-09-20 01:19:37.484395+00	t	t	6	141	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 85, "processing_time_us": 141}
68	8WPtrSQo	2025-09-20 01:19:37.524419+00	t	t	6	178	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 99, "processing_time_us": 178}
69	4nRfojQD	2025-09-20 01:19:37.661334+00	t	t	6	146	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 85, "processing_time_us": 146}
70	4nRfojQD	2025-09-20 01:19:37.670759+00	t	t	6	156	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 90, "processing_time_us": 156}
71	5XcBi1TF	2025-09-20 01:19:37.872906+00	t	t	6	124	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 76, "processing_time_us": 124}
72	5XcBi1TF	2025-09-20 01:19:37.882494+00	t	t	6	185	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 118, "processing_time_us": 185}
73	4AFvYuKe	2025-09-20 01:19:39.647865+00	t	t	6	131	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 82, "processing_time_us": 131}
74	4fxXLf9F	2025-09-20 01:19:39.653701+00	t	t	6	161	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 112, "processing_time_us": 161}
75	3749frAc	2025-09-20 01:19:39.655446+00	t	t	6	114	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 66, "processing_time_us": 114}
76	4AFvYuKe	2025-09-20 01:19:39.656859+00	t	t	6	121	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 66, "processing_time_us": 121}
77	4fxXLf9F	2025-09-20 01:19:39.663905+00	t	t	6	122	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 68, "processing_time_us": 122}
78	5hCJDtCt	2025-09-20 01:19:39.682854+00	t	t	6	124	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 75, "processing_time_us": 124}
79	5hCJDtCt	2025-09-20 01:19:39.687897+00	t	t	6	155	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 91, "processing_time_us": 155}
80	LSJry4XQ	2025-09-20 01:19:39.789272+00	t	t	6	145	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 86, "processing_time_us": 145}
81	LSJry4XQ	2025-09-20 01:19:39.790606+00	t	t	6	138	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 81, "processing_time_us": 138}
82	2K5u18dn	2025-09-20 01:19:39.897001+00	t	t	6	160	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 98, "processing_time_us": 160}
83	3PjDLYJu	2025-09-20 01:19:40.168501+00	t	t	4	92	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 57, "processing_time_us": 92}
84	wfqYzXdx	2025-09-20 01:19:42.135196+00	t	t	6	136	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 85, "processing_time_us": 136}
85	3k69sfWs	2025-09-20 01:19:42.136442+00	t	t	6	117	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 69, "processing_time_us": 117}
86	3yzybfwb	2025-09-20 01:19:42.138736+00	t	t	6	112	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 66, "processing_time_us": 112}
87	5cqFp8zQ	2025-09-20 01:19:42.13886+00	t	t	6	97	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 54, "processing_time_us": 97}
88	wfqYzXdx	2025-09-20 01:19:42.141852+00	t	t	6	141	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 92, "processing_time_us": 141}
89	3k69sfWs	2025-09-20 01:19:42.14328+00	t	t	6	113	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 65, "processing_time_us": 113}
90	5cqFp8zQ	2025-09-20 01:19:42.147004+00	t	t	6	129	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 79, "processing_time_us": 129}
91	5UhKctNn	2025-09-20 01:19:42.14968+00	t	t	6	122	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 73, "processing_time_us": 122}
92	55RHkwoV	2025-09-20 01:19:42.202703+00	t	t	6	156	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 95, "processing_time_us": 156}
93	5NTMojdc	2025-09-20 01:19:42.776214+00	t	t	6	157	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 97, "processing_time_us": 157}
94	2NcT445r	2025-09-20 01:19:42.918484+00	t	t	6	147	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 94, "processing_time_us": 147}
95	2NcT445r	2025-09-20 01:19:42.921922+00	t	t	6	128	\N	\N	\N	\N	\N	{"stream_id": 1, "arbitrage_time_us": 79, "processing_time_us": 128}
96	4B62Hgbo	2025-09-20 01:19:43.506119+00	t	t	6	121	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 73, "processing_time_us": 121}
97	MASEUGuR	2025-09-20 01:19:44.204723+00	t	t	6	161	\N	\N	\N	\N	\N	{"stream_id": 2, "arbitrage_time_us": 98, "processing_time_us": 161}
\.


--
-- TOC entry 3458 (class 0 OID 16390)
-- Dependencies: 215
-- Data for Name: orderbook_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orderbook_snapshots (id, "timestamp", slot, venue, market, best_bid, best_ask, mid_price, spread_bps, bid_depth_usd, ask_depth_usd, total_bids, total_asks, raw_orderbook) FROM stdin;
\.


--
-- TOC entry 3464 (class 0 OID 16432)
-- Dependencies: 221
-- Data for Name: venue_performance; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.venue_performance (id, venue_pair, date, total_opportunities, executed_opportunities, successful_executions, total_profit_bps, average_profit_bps, average_execution_time_us, success_rate_pct, last_updated) FROM stdin;
\.


--
-- TOC entry 3474 (class 0 OID 0)
-- Dependencies: 216
-- Name: arbitrage_opportunities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.arbitrage_opportunities_id_seq', 644, true);


--
-- TOC entry 3475 (class 0 OID 0)
-- Dependencies: 218
-- Name: execution_results_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.execution_results_id_seq', 97, true);


--
-- TOC entry 3476 (class 0 OID 0)
-- Dependencies: 214
-- Name: orderbook_snapshots_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.orderbook_snapshots_id_seq', 1, false);


--
-- TOC entry 3477 (class 0 OID 0)
-- Dependencies: 220
-- Name: venue_performance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.venue_performance_id_seq', 1, false);


--
-- TOC entry 3297 (class 2606 OID 16413)
-- Name: arbitrage_opportunities arbitrage_opportunities_opportunity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.arbitrage_opportunities
    ADD CONSTRAINT arbitrage_opportunities_opportunity_id_key UNIQUE (opportunity_id);


--
-- TOC entry 3299 (class 2606 OID 16411)
-- Name: arbitrage_opportunities arbitrage_opportunities_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.arbitrage_opportunities
    ADD CONSTRAINT arbitrage_opportunities_pkey PRIMARY KEY (id);


--
-- TOC entry 3305 (class 2606 OID 16427)
-- Name: execution_results execution_results_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.execution_results
    ADD CONSTRAINT execution_results_pkey PRIMARY KEY (id);


--
-- TOC entry 3295 (class 2606 OID 16398)
-- Name: orderbook_snapshots orderbook_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orderbook_snapshots
    ADD CONSTRAINT orderbook_snapshots_pkey PRIMARY KEY (id);


--
-- TOC entry 3312 (class 2606 OID 16443)
-- Name: venue_performance venue_performance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.venue_performance
    ADD CONSTRAINT venue_performance_pkey PRIMARY KEY (id);


--
-- TOC entry 3314 (class 2606 OID 16445)
-- Name: venue_performance venue_performance_venue_pair_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.venue_performance
    ADD CONSTRAINT venue_performance_venue_pair_date_key UNIQUE (venue_pair, date);


--
-- TOC entry 3300 (class 1259 OID 16417)
-- Name: idx_arbitrage_opportunity_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_arbitrage_opportunity_id ON public.arbitrage_opportunities USING btree (opportunity_id);


--
-- TOC entry 3301 (class 1259 OID 16416)
-- Name: idx_arbitrage_profit; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_arbitrage_profit ON public.arbitrage_opportunities USING btree (profit_bps);


--
-- TOC entry 3302 (class 1259 OID 16414)
-- Name: idx_arbitrage_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_arbitrage_timestamp ON public.arbitrage_opportunities USING btree ("timestamp");


--
-- TOC entry 3303 (class 1259 OID 16415)
-- Name: idx_arbitrage_venues; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_arbitrage_venues ON public.arbitrage_opportunities USING btree (venue_sell, venue_buy);


--
-- TOC entry 3306 (class 1259 OID 16430)
-- Name: idx_execution_opportunity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_execution_opportunity ON public.execution_results USING btree (opportunity_id);


--
-- TOC entry 3307 (class 1259 OID 16429)
-- Name: idx_execution_success; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_execution_success ON public.execution_results USING btree (success);


--
-- TOC entry 3308 (class 1259 OID 16428)
-- Name: idx_execution_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_execution_timestamp ON public.execution_results USING btree ("timestamp");


--
-- TOC entry 3291 (class 1259 OID 16401)
-- Name: idx_orderbook_slot; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orderbook_slot ON public.orderbook_snapshots USING btree (slot);


--
-- TOC entry 3292 (class 1259 OID 16399)
-- Name: idx_orderbook_timestamp; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orderbook_timestamp ON public.orderbook_snapshots USING btree ("timestamp");


--
-- TOC entry 3293 (class 1259 OID 16400)
-- Name: idx_orderbook_venue_market; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_orderbook_venue_market ON public.orderbook_snapshots USING btree (venue, market);


--
-- TOC entry 3309 (class 1259 OID 16446)
-- Name: idx_venue_performance_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_venue_performance_date ON public.venue_performance USING btree (date);


--
-- TOC entry 3310 (class 1259 OID 16447)
-- Name: idx_venue_performance_pair; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_venue_performance_pair ON public.venue_performance USING btree (venue_pair);


-- Completed on 2025-09-22 07:27:55 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict 6RILFPxqnadfCDJCVskCmy4SNeEOXWf4wkWlrY94xKpyOlpadHmvXykkPFvAYD7

